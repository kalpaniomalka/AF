##This is the sample react application for starting react and express based projects.

This includes;

    express
    mongoose
    react
    react-dom
    react-router-dom
    bootstart
    parcel
 
 **Install dependencies**
 
    npm intall
 
 **Start**
 
 Make sure mongo DB is running on localhost 27017.
 
    npm start


###Referecnces

* https://nodejs.org/dist/latest-v10.x/docs/api/
* https://expressjs.com/en/4x/api.html
* https://reactjs.org/docs/getting-started.html
* https://reacttraining.com/react-router/web/guides/quick-start
* https://parceljs.org/getting_started.html
* https://developer.mozilla.org/en-US/docs/Web/JavaScript
* https://getbootstrap.com/docs/4.3/getting-started/introduction/
* https://www.w3schools.com/
* https://docs.mongodb.com/manual/tutorial/getting-started/
* https://mongoosejs.com/docs/guide.html


* npm registry https://registry.npmjs.org/
